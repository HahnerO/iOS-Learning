//
//  LoginViewController.h
//  GayHub
//
//  Created by 王籽涵 on 2020/7/8.
//  Copyright © 2020 Hahn Tech. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LoginView;

NS_ASSUME_NONNULL_BEGIN

@interface LoginViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
