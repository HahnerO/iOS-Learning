//
//  UserState.h
//  GayHub
//
//  Created by 王籽涵 on 2020/7/8.
//  Copyright © 2020 Hahn Tech. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface UserState : NSObject

@property(nonatomic) BOOL didLogin;

@end

NS_ASSUME_NONNULL_END
