//
//  UserState.m
//  GayHub
//
//  Created by 王籽涵 on 2020/7/8.
//  Copyright © 2020 Hahn Tech. All rights reserved.
//

#import "UserState.h"

@interface UserState ()

@end

@implementation UserState

- (instancetype)init
{
    self = [super init];
    if (self) {
    }
    return self;
}

@end
