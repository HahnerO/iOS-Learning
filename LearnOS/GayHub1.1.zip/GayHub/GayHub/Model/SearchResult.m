//
//  SearchResult.m
//  GayHub
//
//  Created by 王籽涵 on 2020/7/27.
//  Copyright © 2020 Hahn Tech. All rights reserved.
//

#import "SearchResult.h"


@implementation SearchResult


@end
