//
//  LoginView.h
//  GayHub
//
//  Created by 王籽涵 on 2020/7/8.
//  Copyright © 2020 Hahn Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoginView : UIView

// comment: check下这些属性外部有无调用，如果没有，就收敛到extension里面
// re: 一开始为了解耦把button的暴露在VC中进行target-action

@end

NS_ASSUME_NONNULL_END
