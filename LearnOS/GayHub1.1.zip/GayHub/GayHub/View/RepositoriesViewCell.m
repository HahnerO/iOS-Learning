//
//  RepositoriesViewCell.m
//  GayHub
//
//  Created by 王籽涵 on 2020/7/12.
//  Copyright © 2020 Hahn Tech. All rights reserved.
//

#import "RepositoriesViewCell.h"

@implementation RepositoriesViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
